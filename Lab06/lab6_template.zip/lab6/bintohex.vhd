-- Alternative Implementation of binary to hex converter example
-- that uses array constant
library IEEE; -- allows the use of STD_LOGIC and STD_LOGIC Vectors
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.all;

entity BINTOHEX is
   port(I : in STD_LOGIC_VECTOR(3 downto 0);
        O : out STD_LOGIC_VECTOR(6 downto 0));
end BINTOHEX;

architecture ARRY_IMPLEMENTATION of BINTOHEX is
   type LED is array (integer range 0 to 15) of STD_LOGIC_VECTOR(6 downto 0);
   constant HEXOUT : LED := ("1000000", "1111001", "0100100", "0110000", "0011001", "0010010", 
                              "0000010", "1111000", "0000000", "0011000", "0001000", "0000011", 
                              "1000110", "0100001", "0000110", "0001110" );
   begin
   O <= HEXOUT(conv_integer(I));

end ARRY_IMPLEMENTATION;
