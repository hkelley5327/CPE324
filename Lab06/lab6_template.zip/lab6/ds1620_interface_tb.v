
`timescale 1ms/1ps
module ds1620_interface_tb ();


    reg TRIG, CLK_IN;
    wire CLK_OUT,RST,DQ;
    wire [8:0] TEMP;

    initial
        begin
            CLK_IN = 0;
            TRIG = 1;
            #42
            TRIG = 0;
        end

    always
        begin 
        CLK_IN = #21 ~CLK_IN;
        end

    ds1620_interface UUT(TRIG, CLK_IN,CLK_OUT,RST,DQ,TEMP);

endmodule
