-- TOP Level Design of DS 1620 Temperature Display Design
-- B. Earl Wells, February 22, 2026

library IEEE;
use IEEE.STD_LOGIC_1164.ALL; 

entity lab6_ptb is 
   port
      (
      CLOCK_50 : in  STD_LOGIC;
      KEY      : in  STD_LOGIC_VECTOR(3 downto 3);
      SW       : in  STD_LOGIC_VECTOR(1 downto 0);
      DQ       : inout  STD_LOGIC;
      CLK_OUT  : out  STD_LOGIC;
      RST      : out  STD_LOGIC;
      HEX3     : out  STD_LOGIC_VECTOR(6 downto 0);
      HEX4     : out  STD_LOGIC_VECTOR(6 downto 0);
      HEX5     : out  STD_LOGIC_VECTOR(6 downto 0);
      HEX6     : out  STD_LOGIC_VECTOR(6 downto 0);
      LEDG8    : out STD_LOGIC;
      LEDG6    : out STD_LOGIC;
      LEDR0    : out STD_LOGIC;
      LEDR1    : out STD_LOGIC
      );
end lab6_ptb;

architecture STRUCTURAL of lab6_ptb is 

   component CLOCK_DIVIDE
      port(CLK_IN  : in STD_LOGIC;
		   CLK_OUT : out STD_LOGIC);
   end component;

   component TEMP2BCD
      port(FAR_CEL : in STD_LOGIC;
           TMPIN   : in STD_LOGIC_VECTOR(8 downto 0);
           BCD_OUT : out STD_LOGIC_VECTOR(15 downto 0));
   end component;

   component DS1620_INTERFACE
      port(TRIG    : in STD_LOGIC;
           CLK_IN  : in STD_LOGIC;
           CLK_OUT : out STD_LOGIC;
           RST     : out STD_LOGIC;
           DQ      : inout STD_LOGIC;
           TEMP    : out STD_LOGIC_VECTOR(8 downto 0));
   end component;

   component bintohex
      port(I : in STD_LOGIC_VECTOR(3 downto 0);
           O : out STD_LOGIC_VECTOR(6 downto 0));
   end component;
   
   component TRBUF is
      port (
         D  : in STD_LOGIC;
         EN : in STD_LOGIC;
         O  : inout STD_LOGIC
      );
   end component;

   signal BCD_OUT     : STD_LOGIC_VECTOR(15 downto 0);
   signal DQ_OUT      : STD_LOGIC;
   signal TEMP        : STD_LOGIC_VECTOR(8 downto 0);
   signal DS1620_TRIG : STD_LOGIC;
   signal DS1620_CLK  : STD_LOGIC;

begin 
   
   --Trigger DS1620 temp read cycle once by pressing KEY(3)
   --OR by continuously by switching slide sw(1) to the up position
   DS1620_TRIG <= (NOT KEY(3)) OR SW(1);
   
   --Light up LEDs above switches when DS1620_interface TRIG input is high
   LEDR1 <= DS1620_TRIG; 
   LEDG6 <= DS1620_TRIG;
   
   LEDR0 <= SW(0); --Light up LEDR(0) When slide switch SW(0) is in
                       --Up position to indicate Celcius Reading
   
   LEDG8 <= '1'; -- Continuously light up decimal point on display

   C1 : CLOCK_DIVIDE port map(CLOCK_50,DS1620_CLK);

   C2 : TEMP2BCD port map (SW(0),TEMP,BCD_OUT);

   C3 : DS1620_INTERFACE port map (DS1620_TRIG,DS1620_CLK,CLK_OUT,RST,DQ,TEMP);
   
   C4 : BINTOHEX port map (BCD_OUT(3 downto 0),HEX3);

   C5 : BINTOHEX port map (BCD_OUT(7 downto 4),HEX4);

   C6 : BINTOHEX port map (BCD_OUT(11 downto 8),HEX5);

   C7 : BINTOHEX port map (BCD_OUT(15 downto 12),HEX6);

end STRUCTURAL; 
