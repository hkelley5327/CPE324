`timescale 1us/1ps

// Frequency in Hz
`define FREQ 23.8 // ~DE2-115 Freq

// Number of Temperature Convert/Temperature Read Cycles
`define TEMP_CNV_READ_CYCLES 4

// Number of Simulations clock per Temperature TRIG/Reading Cycle
`define SIM_CLKS_PER_TEMP 31
`define period(freq) 1000000.0/(freq)

module ds1620_interface_tb3 ();

    parameter PERIOD = `period(`FREQ);
    parameter HALF_PERIOD = `period(`FREQ)*0.5;
    parameter TRIG_INTERVAL = `SIM_CLKS_PER_TEMP * `period(`FREQ);
    
    reg TRIG, CLK_IN=0;
    wire CLK_OUT,RST,DQ;
    wire [8:0] TEMP;

	 
    initial
        begin:TRIG_Control
		  	   integer i; // local variable i
		      for (i=0;i<`TEMP_CNV_READ_CYCLES;i=i+1)
				begin
                TRIG = 1;
                #(PERIOD) // Set TRIG to 1 for one cycle
                TRIG = 0; 
					 #TRIG_INTERVAL; // Wait one Temp conv/Read Simulation cycle
                                // before reactivating TRIG again
				end
					
        end
            
    initial
        begin:CLK_IN_Control
		      integer i; // local variable i
            for (i=0;i<=(2*(`SIM_CLKS_PER_TEMP+1)*(`TEMP_CNV_READ_CYCLES));
                 i = i+1)
            begin
                CLK_IN = #(HALF_PERIOD) ~CLK_IN;
            end
				$stop; // stop the simulation after the clock cycles are complete
				       // even if there is a temperature conversions that is pending
        end

    ds1620_interface UUT(TRIG, CLK_IN,CLK_OUT,RST,DQ,TEMP);
    ds1620 C1(CLK_OUT,RST,DQ);

endmodule


// Verilog  Module to Model base DS1620 operation when in the
// standby/temperature conversion mode and the base read temperature
// operation when in the 3-wire mode 
// template by
// B. Earl Wells, ECE Department University of Alabama in Huntsville
module ds1620(input CLK_CONV, RST, inout DQ);


    reg tri_en=0, dq_out;

    reg [8:0]  current_temp = -9'd1;

    reg [7:-1] temp_val [0:3];
    
    initial
    begin 
        temp_val[0] = -40*2; //-40 degrees cel
        temp_val[1] =  25*2; // 25 degrees cel
        temp_val[2] = 125*2; // 125 degress cel -highest rated for DS1620
        temp_val[3] = -55*2; // -55 degress cel -lowest rated for DS1620
    end
               
    reg read_cmd_flg = 1; // flag to indicate that the DS1620 is in the
                          // read command mode

    reg write_cur_temp_flg = 0; // flag to indicate that the DS1620 is in
                                // the temperature output mode

    reg com_rec_mode = 1; // DS1620 Command Receive Mode Flag
    reg data_snd_mode = 0; // DS1620 Data Output Send Mode Flag
    reg [7:0] command = 8'd0;
    
    always @(posedge CLK_CONV)
    begin:rising_edge    
        if (RST==1 && com_rec_mode==1)
        begin
		      data_snd_mode = 0;
            command = {DQ,command[7:1]};
            if (command == 8'haa) 
            begin
                command = 8'd0; // get ready for next command
                $display("Time: %.3f -- Read Temp Command Decoded by the DS1620",$realtime);
                data_snd_mode=1;
            end
        end
    end 

    reg [3:0] cur_temp_bit_idx = 0;
    reg [1:0] i = 4'd0;    
    always @ (negedge CLK_CONV)
    begin:falling_edge
        if (RST==0)
        begin
            // Convert pulse started
            $printtimescale(ds1620);
            $display("Time: %.3f -- Temperature Conversion Begins",$realtime);
            current_temp <= #750000.0 temp_val[i];
            i <= i + 2'd1;
          end
        else
        // if RST=1 and falling edge of CLK_COUNT
        begin
            if (data_snd_mode==1)
				begin
                if (cur_temp_bit_idx == 0) 
					 begin
                    com_rec_mode <= 0; // make sure command receive mode is turned off
                    tri_en <=1; // enable tristate buffer
						  $display("Time: %.3f -- Temperature Data Sending begun by the DS1620",$realtime); 
					 end
                dq_out <= current_temp[cur_temp_bit_idx];
                if (cur_temp_bit_idx<=8)
                begin
                    cur_temp_bit_idx <= cur_temp_bit_idx + 4'd1;
                end
                else
			       begin	
				       cur_temp_bit_idx <=4'd0;
						 com_rec_mode <= 1;
						 tri_en <=0;
						 $display("Time: %.3f\t-- Sending of Temperature Data from the DS1620 Complete",$realtime);
						 $display("          \t        [Current Temperature Value Sent = \"%b\"]\n",current_temp); 

					 end
            end
        end
    end		 

    assign DQ = (tri_en) ? dq_out : 1'bz;

endmodule
