// Verilog  Module to input temperature data from the DS 1620 
// temperature IC
// template by
// B. Earl Wells, ECE Department University of Alabama in Huntsville
// inputs:
//    TRIG an active high Trigger input which execute 31 clock cycle
//        temperature conversion/temperature reading cycle.
//        This cycle is composed of three parts:
//           1) initiate temperature conversion by sending a ~conv pulse
//              when the DS 1620 is in its stand-alone mode
//           2) wait 10 cycles while DS 1620 in stand-alone mode for
//              temperature conversion to take place
//           3) initiate 3-wire communication mode of the DS 1620 and
//              issue read temperature command to DS1620 and receive
//              the 9 bit temperature from it. After which return 
//              DS1620 to stand-alone mode
//           
//    CLK_IN the input clock (must be less than 1.7 MHZ)
//
// outputs:
//    TEMP the temperature acquired from the DS 1620 in 9 bit two's
//        complement format. (Output Resolution is 1/2 degree C)
//    CLK_OUT the clocking signal that drives the DS 1620 during its
//        "three wire" communication as well as providing the start 
//        conversion pulse when the DS 1620 is in the stand-alone mode
//        that causes the DS 1620 to perform the next temperature
//        conversion
//    RST the reset control line of the DS 1620 which is high during 
//        "three wire" communication but low for stand-alone mode
//    TRI_EN the controling signal for the external tristate buffer.
//        This signal indicates when the DQ input of the external 
//        DS 1620 will be driven by DQ_OUT (this occurs when TRI_EN='1')
//        or when the DS 1620 will drive the DQ_IN input (this occurs 
//        when TRI_EN='0') 
//    DQ  the inout signal that is used to input temperature data produce by 
//        the DS 1620 IC and outputs command data to the 1620 when the
//        Interface is in 3 wire mode. Note that the input data received from
//        the 1620 IC is always an immediate response to a command issued 
//        the interface. When data is sent from the DS 1620, it is in a 
//        bit serial manner (least significant bit first). Such 
//        data is assumed to be valid at the rising edge of the CLK_OUT
//        signal. In this design, the DQ signal is used to receive
//        the 9 bit Celcius temperature from the DS 1620 after it has
//        received the "read temperature" command from the ds1620_interface.


module ds1620_interface(input TRIG, CLK_IN, 
    output CLK_OUT,RST,inout DQ, output reg [8:0] TEMP);
      
    // dq_out: this internal signal is used to drive the DQ 
    //     bidirectional inout signal of the ds1620 inteface
    //     during "three wire" communication. Communication using
    //     this signal occurs is synchronized closely with the
    //     CLK_OUT signal. Such communication is bit serial with 
    //     with data being sent least significant bit first and 
    //     the valid logic value of each bit being placed on the
    //     the dq_out line at least 50 ns before the rising edge
    //     edge of CLK_OUT. Note in this design, dq_out is used to
    //     send the read temperature command to the DS 1620.
    reg dq_out;

    // tri_en: this internal signal is used to enable the tri-state
    //      buffer that allows the internal dq_out signal to drive 
    //      the DQ inout signal 
    reg tri_en=0;
     
    // one way to selectively echo the CLK_IN signal to the CLK_OUT
    // signal is to employ a continous assignment statement that 
    // first logically OR's the CLK_IN signal with the OR mask
    // value and then AND's this result with an AND mask. The AND Mask 
    // will always force the CLK_OUT signal low if it is low.  If the AND mask is 
    // high and the OR mask low then the original CLK_IN Value is passed
    // to CLK_OUT unabated. If the AND mask is a high and the OR mask is low
    // then CLK_OUT will always be high. The key here is to set these masks 
    // appropriately at strategic points in the waveform.    
    reg and_mask = 1, or_mask = 1;


    reg [4:0] cycle_count = 5'd0; // clock cycle count
    reg [8:0] next_temp;          // next temperature value
    reg rst;
    
    // Enter your model for the DS1620_INTERFACE HERE!
    // enter your modeling code here
    // Ƹ̵̡Ӝ̵̨̄Ʒ   ô¿ô    <*_*>    @('_')@
    //
    //  ¯\_(ツ)_/¯ 
    //      

endmodule
