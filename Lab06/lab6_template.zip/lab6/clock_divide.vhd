-- VHDL module for clock divider
-- B. Earl Wells, ECE Department University of Alabama in Huntsville

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

-- Input parameter
--      CLK_IN 50 MHZ input clock
-- Output parameter
--      CLK_OUT slower output clock
entity CLOCK_DIVIDE is
   PORT(
		CLK_IN	: in  STD_LOGIC;
		CLK_OUT 	: out	STD_LOGIC);
end CLOCK_DIVIDE;

architecture BEHAVIORAL of CLOCK_DIVIDE is
signal NXT_CLK : STD_LOGIC_VECTOR (20 downto 0);
begin
process (CLK_IN)
begin
   if (CLK_IN'event and CLK_IN = '1') then
      NXT_CLK <= NXT_CLK + '1';
      CLK_OUT <= NXT_CLK(20);
   end if;
end process;

end BEHAVIORAL;

