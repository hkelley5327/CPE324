module alarm_clock(input CLOCK_50,input[3:0]KEY,input[1:0]SW,output [6:0] HEX7,HEX6,HEX5,HEX4,HEX3,HEX2,output reg d_bit);
	reg [41:0] cycles;
	reg [5:0] sec,min,hour;
	reg [5:0] a_sec,a_min,a_hour;
	reg [7:0] sec_bcd,min_bcd,hour_bcd;
	reg alarm_on, alarm_past;
	reg active, count, sw0_prev, sw1_prev, k3_prev,k2_prev,k1_prev,k0_prev;
	wire not_key0,not_key1,not_key2,not_key3,k3,k2,k1,k0,sw0;

	assign not_key0 = ~KEY[0];
	assign not_key1 = ~KEY[1];
	assign not_key2 = ~KEY[2];
	assign not_key3 = ~KEY[3];

	debounce C0 (.clk(CLOCK_50),.d_in(not_key3),.d_out(k3));
	debounce C1 (.clk(CLOCK_50),.d_in(not_key2),.d_out(k2));
	debounce C2 (.clk(CLOCK_50),.d_in(not_key1),.d_out(k1));
	debounce C4 (.clk(CLOCK_50),.d_in(not_key0),.d_out(k0));
	debounce C5 (.clk(CLOCK_50),.d_in(SW[0]),.d_out(sw0));
	debounce C6 (.clk(CLOCK_50),.d_in(SW[1]),.d_out(sw1));
	
	initial begin
		active = 1;
		alarm_on = 0;
		cycles = 0;
		hour = 0;
		sec = 0; 
		d_bit = 0;
		min = 0;
	end
	
	always @(posedge CLOCK_50) begin
		sw0_prev <= sw0;
		sw1_prev <= sw1;
		k3_prev <= k3;
		k2_prev <=k2;
		k1_prev <= k1;
		
		if ((hour==a_hour)&&(min==a_min)&&(sec==a_sec))
			alarm_on <= 1;
		if (((hour==a_hour)&&(min==(a_min+5))&&(sec==a_sec))||(k0))
			alarm_on <= 0;
		if (alarm_on && (cycles % 50000 == 0)) begin
			d_bit <= ~d_bit;
		end
		
		if (~sw0_prev && sw0) begin
			active <= 0;
			hour <= 0;
			min <= 0;
			sec <= 0;
		end 
		else if (sw0) begin
			active <= 0;
			if (k3 && !k3_prev) begin
				if (hour < 23) hour <= hour + 1;
				else hour <= 0;
			end
			if (k2 && !k2_prev) begin
				if (min < 59)
				min  <= min + 1;
				else min <= 0;
				end
			if (k1 && !k1_prev) begin
				if (sec < 59)
				sec  <= sec + 1;
				else sec <= 0;
				end
			if (k0) begin
				hour <= 0;
				min <= 0;
				sec <= 0;
			end
		end
		else begin active <= 1; end
		
		if (sw1) begin // alarm set mode
			active <= 1;
			if (k3 && !k3_prev) begin
				if (a_hour < 23) a_hour <= a_hour + 1;
				else a_hour <= 0;
			end
			if (k2 && !k2_prev) begin
				if (a_min < 59)
				a_min  <= a_min + 1;
				else a_min <= 0;
				end
			if (k1 && !k1_prev) begin
				if (a_sec < 59)
				a_sec  <= a_sec + 1;
				else a_sec <= 0;
				end
			if (k0) begin
				a_hour <= 0;
				a_min <= 0;
				a_sec <= 0;
			end
		end
		
		if (active) begin
			cycles <= cycles + 1;
			if (cycles % 50000000 == 0) begin
				if (sec == 59) begin
					sec <= 0;
					if (min == 59) begin
						min <= 0;
						if (hour == 23) begin
							hour <= 0;
							min <= 0;
							sec <= 0;
						end else begin
							hour <= hour + 1;
						end
					end else begin
						min <= min + 1;
					end
				end else begin
					sec <= sec + 1;
				end
			end
		end
	end
	
//	always @(SW[0]) begin
//	if (~SW[0]) begin // Set time mode
//		active = 0;
//		hour = 0;
//		sec = 0; 
//		min = 0;
//		count = 0;
//		while (SW[0] == 0 & (count < 1000000)) begin // Set time mode
//			if (k3) begin
//			hour = hour + 1; end
//			if (k2) begin
//			min = min + 1; end
//			if (k1) begin
//			sec = sec + 1; end
//			count = count + 1;
//		end
//		active = 1;
//	end
//	end
	
	// Continuously convert time to hex display
	always @(*) begin
	 if (~sw1) begin
		sec_bcd <= bintobcd(sec);
		min_bcd <= bintobcd(min);
		hour_bcd <= bintobcd(hour);
	 end else begin
		sec_bcd <= bintobcd(a_sec);
		min_bcd <= bintobcd(a_min);
		hour_bcd <= bintobcd(a_hour);
	 end
	
	
		bintohex(sec_bcd[3:0],HEX2);
		bintohex(sec_bcd[7:4],HEX3);
		
		bintohex(min_bcd[3:0],HEX4);
		bintohex(min_bcd[7:4],HEX5);
		
		bintohex(hour_bcd[3:0],HEX6);
		bintohex(hour_bcd[7:4],HEX7);
	end

	

 task bintohex (input [3:0] bin_num, output [6:0] hex_num);
      case (bin_num)
         0  : hex_num <= 7'b1000000;
         1  : hex_num <= 7'b1111001;
         2  : hex_num <= 7'b0100100;
         3  : hex_num <= 7'b0110000;
         4  : hex_num <= 7'b0011001;
         5  : hex_num <= 7'b0010010;
         6  : hex_num <= 7'b0000010;
         7  : hex_num <= 7'b1111000;
         8  : hex_num <= 7'b0000000;
         9  : hex_num <= 7'b0011000;
         10 : hex_num <= 7'b0001000;
         11 : hex_num <= 7'b0000011;
         12 : hex_num <= 7'b1000110;
         13 : hex_num <= 7'b0100001;
         14 : hex_num <= 7'b0000110;
         15 : hex_num <= 7'b0001110;
			default : hex_num <= 7'bx;
      endcase
   endtask


 function [7:0] bintobcd;
      input [5:0] bin_num;
      reg [7:0] bcd_num=0;
      reg [5:0] residual;

      reg [1:0] i;
      for (i=0;i<=1;i=i+1)
         begin
            residual=bin_num/10;             
            bcd_num=bcd_num+((bin_num-residual*10)<<4*i);
            bin_num=residual;
         end
      bintobcd=bcd_num; 
   endfunction

endmodule


module debounce (input clk,d_in, output reg d_out);

   always @(posedge clk)
      begin:MAIN_LOOP
         reg [7:0] hld_sig = 8'd0;
         reg [4:0] index = 0;
         reg [14:0] count = 15'd0;
         reg d_st = 0;       
         // increment internal prescaler counter until value is at max
         if (count == 15'd32767)
            begin
            count = 0; // then evaluate debounce 
                       // invert signal and place in 8 bit array
            hld_sig[index] = d_in; 
            // implement a circular buffer
            if (index == 7)
               index = 0;
            else
               index = index + 1;
            // stay in state 0 until for 8 consecutive bit times the 
            // input signal has been at a logic 1
            if (!d_st)
               begin
               d_st = hld_sig[0]&hld_sig[1]&hld_sig[2]&hld_sig[3]&
                      hld_sig[4]&hld_sig[5]&hld_sig[6]&hld_sig[7];
               d_out = d_st;
               end
            // stay in state 1 until for 8 consecutive bit times the 
            // input signal has been at a logic 0 
            else
               begin
               d_st = hld_sig[0]|hld_sig[1]|hld_sig[2]|hld_sig[3]|
                      hld_sig[4]|hld_sig[5]|hld_sig[6]|hld_sig[7];
               d_out = d_st;
               end
            end
         else 
            // if COUNT value not at its max value increment it by one
            count = count + 1;
      end

endmodule

